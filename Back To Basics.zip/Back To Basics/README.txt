Better Bamboo by DJPeters
Version: 1.0.0

Introduction:

This is a simple pack with a simple purpose--it makes every recipe which requires sticks craftable using bamboo. It also removes the recipe for making sticks out of bamboo, as there's no use for it if the items can perform the same function.